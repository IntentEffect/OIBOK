# Project OI Body of Knowledge

# CORR-002 — Bibliographic, AI Evidence and Derived-Register Regeneration Pass

**Artefact ID:** OI-BOK-CORR-002  
**Version:** 0.1  
**Status:** Complete; final consistency proof remains  
**Source chapters:** OI-BOK-001 through OI-BOK-010 v0.2  
**Corrected chapters:** OI-BOK-001 through OI-BOK-010 v0.3  
**Review authority:** OI-BOK-REVIEW-001  
**Date:** 15 August 2026

---

## 1. Result

CORR-002 has completed the second bounded correction stage.

It produced:

- ten bibliographically normalised v0.3 chapters;
- a tiered glossary v0.2 with 432 entries and a core index;
- a regenerated 182-proposition register;
- a layered diagnostic index with 437 failure modes, 205 quality dimensions and 253 semantic indicators;
- regenerated cross-chapter traceability;
- a dispositioned open-question register;
- an updated release-candidate index and source manifest;
- a 338-row bibliographic verification register;
- and a 18-record AI evidence lifecycle register.

## 2. Bibliographic Scope

The pass normalised the complete internal reference apparatus and validated all chapter footnote links.

It also completed primary-source or official-page verification for the time-sensitive AI and AI-agent evidence set. The earlier generic duplicate NIST Agent entry was consolidated, and LongMemEval was added, producing 18 distinct lifecycle records.

It corrected or upgraded:

- Anthropic author and page metadata;
- the final 791-person Cybernetic Teammate publication distinction;
- the software-developer study author list retained from CORR-001;
- the draft status of the NCCoE identity and authorisation concept paper;
- the publication date and evidence type of NIST AI 800-5;
- and AgentPoison from arXiv to the final NeurIPS publication.

Stable older sources were structurally reconciled and normalised against the chapter citations and identifiers. CORR-002 does not claim that all older monographs and journal records were independently reopened at publisher pages.

## 3. Glossary Tiering

The glossary now distinguishes:

```text
T1 Core construct and model vocabulary
T2 Domain-owned preferred terms
T3 Cross-cutting governance and responsible-use terms
T4 Working diagnostic or research terms
T5 Implementation heuristics
T6 Discouraged or deprecated language
```

The full extended glossary remains available, while the core index provides the reader-facing vocabulary.

## 4. Diagnostic Layering

The release-facing diagnostic architecture now begins with:

- seven primary failure classes;
- sixteen quality families;
- and eight evidence roles.

The source-level 437 failure modes, 205 quality dimensions and 253 indicators remain available for research traceability and are not one assessment checklist.

## 5. Derived-Register Regeneration

PROP, DIAG, TRACE, OPEN and INDEX have been regenerated against the corrected v0.3 chapter set and GLO v0.2.

The Chapter 1 quality asymmetry is now reflected in:

- eight source-owned Sense quality dimensions;
- 205 total quality dimensions;
- updated chapter traceability;
- and the release index.

## 6. Remaining Work

One bounded activity remains:

> **Final source-to-derived consistency proof and OI-BOK-RELEASE-001**

It must confirm:

- no stale v0.1 or v0.2 references remain in active v0.2 derived artefacts;
- all source and derived counts reconcile;
- every review correction is closed or explicitly deferred;
- all current AI evidence statuses remain valid;
- checksums and bundles are complete;
- and the release record states the exact claims and limitations of v1.0.

## 7. Workstream Boundary

The product, architecture, implementation-pattern and blog workstreams remain paused until OI-BOK-RELEASE-001 exists.

---

## 8. Guardrail

> **CORR-002 improves source integrity, terminology layering and traceability. It does not convert the BOK into a validated theory, diagnostic instrument or maturity model.**
