# Project OI Body of Knowledge

# Chapters 1–5 Synthesis and Remaining-Chapter Roadmap

**Artefact ID:** OI-BOK-SYN-001  
**Version:** 0.1  
**Status:** Working synthesis and roadmap decision  
**Inquiry:** OI-INQ-001 — What is Organisational Intelligence?  
**Source chapters:** OI-BOK-001 through OI-BOK-005  
**Supporting sources:** Project OI Working Definition v0.2; Project OI Capability Map v0.1; Inquiry 001 Integrated Synthesis; Volume 0 Domain and Meta-Models  
**Roadmap authority:** Governs the remaining Body of Knowledge work after Chapters 1–5 unless superseded by an explicit owner decision  
**Public writing status:** Paused  
**Product implication and implementation-pattern status:** Paused unless required to resolve a BOK construct  
**Architecture reconciliation status:** Deferred until BOK completion  
**Date:** 13 August 2026

---

## 1. Purpose

This artefact reviews the first five Project OI Body of Knowledge chapters as one developing construct and locks a finite path to completion.

It has six purposes:

1. determine whether Chapters 1–5 form a coherent account of the first half of the Organisational Intelligence cycle;
2. reconcile their chapter-level processes with the Project OI working definition and operational capability model;
3. identify overlap, terminology drift and unresolved boundaries;
4. determine which substantive domains remain uncovered;
5. define a finite remaining chapter list and completion package;
6. and prevent the programme from expanding into an open-ended series of adjacent topics.

This is a synthesis and roadmap artefact.

It does not:

- introduce new empirical findings;
- claim that the Project OI construct is validated;
- reconcile Project OI with the product architecture;
- create a maturity model;
- create new public articles;
- or reopen completed chapters for wholesale rewriting.

Where this document states a conclusion drawn from existing chapters, it is a **source-derived synthesis**.

Where it selects a remaining chapter structure, completion package or workstream rule, it is an explicit **roadmap decision**.

---

## 2. Source Basis

### 2.1 Body of Knowledge Chapters Reviewed

| Chapter | Title | Primary contribution |
|---|---|---|
| OI-BOK-001 | Signals and Attention | How events become organisational signals and receive scarce organisational attention |
| OI-BOK-002 | Organisational Context | How information acquires meaning, relevance, authority and appropriate-use conditions |
| OI-BOK-003 | Knowledge and Expertise | How relevant understanding and expertise become organisationally available |
| OI-BOK-004 | Decision and Authority | How orientation becomes an attributable and authorised commitment |
| OI-BOK-005 | Coordination and Collective Action | How decisions become shared commitments and interdependent collective work |

Together, the five chapters contain approximately **39,600 words**, **80 working propositions** and **139 named failure modes**.

Those numbers show that the programme now has enough substantive material to require consolidation before further expansion.

They are not measures of construct quality.

### 2.2 Supporting Project OI Sources

The synthesis also uses the following established Project OI material:

- **Working Definition of Organisational Intelligence v0.2**
- **Project OI Capability Map v0.1**
- **Inquiry 001 Integrated Synthesis: Cohorts 1 and 2**
- **Volume 0 — The OI Domain Model**
- **Volume 0 — The Meta-Model**

These sources establish the programme’s existing commitments:

1. Organisational Intelligence is an emergent organisation-level capability, not a thing stored in one system.
2. The short working definition is organised around:
   - **Orient**
   - **Coordinate**
   - **Improve**
3. The six operational capabilities are:
   - **Sense**
   - **Know**
   - **Choose**
   - **Mobilise**
   - **Learn**
   - **Adapt**
4. The provisional integrated cycle also includes:
   - outcome observation;
   - feedback;
   - memory;
   - and capability reconfiguration.
5. Purpose, governance, evidence quality, authority, accountability, communication, control, ethics and enabling organisational conditions act across the cycle rather than forming one simple linear stage.

---

## 3. Executive Conclusion

### 3.1 Chapters 1–5 Are Coherent

The first five chapters form a coherent account of how an organisation moves from an event in its environment or operations to authorised and coordinated collective action.

Their integrated sequence is:

```text
Event, condition or experience
        ↓
Signal recognition and attention
        ↓
Organisational contextualisation
        ↓
Knowledge and expertise availability
        ↓
Organisational orientation
        ↓
Decision and authority
        ↓
Coordination and collective action
```

The chapters therefore establish the greater part of:

- **Orient**
- **Choose**
- and the coordination portion of **Mobilise**

within the Project OI model.

### 3.2 The Body of Knowledge Is Not Complete

The current sequence stops before it has adequately explained:

- reliable execution;
- the production and observation of consequences;
- feedback quality;
- organisational memory as a complete continuity system;
- reflective and generative learning;
- capability development;
- adaptation and reconfiguration;
- and the integrated governance, measurement, ethical and human–AI conditions of the complete construct.

The defining Project OI feedback loop therefore remains open.

### 3.3 The Existing Higher-Order Model Is Retained

The synthesis retains the current three higher-order transformations:

```text
ORIENT
        ↓
COORDINATE
        ↓
IMPROVE
```

The synthesis also retains the six operational capabilities:

| Higher-order transformation | Operational capability |
|---|---|
| Orient | Sense |
| Orient | Know |
| Coordinate | Choose |
| Coordinate | Mobilise |
| Improve | Learn |
| Improve | Adapt |

No evidence in Chapters 1–5 requires a seventh operational capability.

### 3.4 Context Is a Bridge, Not a Seventh Capability

Organisational Context is sufficiently important to justify its own BOK chapter.

It should not become a seventh operational capability.

Contextualisation is a connective mechanism through which attended signals, source material, current state, history, authority and purpose become usable by **Know** and contribute to orientation.

### 3.5 Outcome Is Not a Capability

An outcome is a consequence or state produced through action and environment.

The organisational capabilities are:

- observing;
- evaluating;
- learning from;
- and adapting through

outcomes.

### 3.6 Connection Quality Is the Integrative Centre

The strongest cross-chapter conclusion is:

> **Organisational Intelligence depends not only on possessing capabilities, but on the reliability and integrity of the transitions among them.**

The first five chapters repeatedly demonstrate that an organisation can:

- notice without contextualising;
- contextualise without locating knowledge;
- know without deciding;
- decide without legitimate authority;
- authorise without coordinating;
- coordinate without reliable execution;
- and act without learning.

Project OI’s plausible integrative contribution remains the explicit treatment of these conversion and handoff boundaries.

### 3.7 The Remaining Chapter Count Is Locked

The Body of Knowledge will contain **ten substantive chapters**.

The remaining chapter sequence is:

6. **Execution and Operational Reliability**
7. **Outcomes, Feedback and Evaluation**
8. **Organisational Memory, Reflection and Learning**
9. **Capability Development and Adaptation**
10. **Integrated and Responsible Organisational Intelligence**

No additional substantive chapter should be added without an explicit roadmap amendment demonstrating that the material cannot be owned coherently by this ten-chapter structure.

---

## 4. Integrated Organisational Intelligence Model

### 4.1 Candidate End-to-End Model

The current integrated model is:

```text
PURPOSE, GOVERNANCE AND RESPONSIBLE CONDITIONS
shape every part of the cycle

Signals and experience
        ↓
SENSE
Notice, qualify and route material signals
        ↓
CONTEXTUALISE
Connect signals to purpose, relationships, state, time,
history, evidence, authority and uncertainty
        ↓
KNOW
Create, validate, locate, combine and apply knowledge and expertise
        ↓
ORIENTATION
Form a sufficiently shared or aligned account of what is happening,
why it matters and what should shape response
        ↓
CHOOSE
Frame the decision, evaluate alternatives and make an authorised commitment
        ↓
MOBILISE
Translate commitment into coordinated and governed collective action
        ↓
EXECUTION
Perform the authorised work reliably while managing variation and failure
        ↓
OUTCOME
Produce intended, unintended, immediate and delayed consequences
        ↓
FEEDBACK AND EVALUATION
Observe and interpret consequences relative to purpose, expectations and evidence
        ↓
LEARN
Revise understanding, assumptions, memory, routines and future response
        ↓
ADAPT
Develop, retire or reconfigure capability, authority, structure and resources
        ↓
Changes future purpose, sensing, knowing, choosing, mobilisation and execution
```

This is a connected capability system, not a rigid linear workflow.

An organisation may:

- move backwards;
- operate several cycles concurrently;
- skip an unnecessary stage;
- perform stages at different organisational levels;
- or repeat part of the cycle before committing further.

### 4.2 Higher-Order Transformations

#### Orient

```text
Sense
→ Contextualise
→ Know
→ Form orientation
```

Orient is the organisation-level capacity to form a sufficiently shared or aligned view of:

- what is happening;
- why it matters;
- what remains uncertain;
- and which conditions should shape response.

#### Coordinate

```text
Choose
→ Authorise
→ Mobilise
→ Execute
```

Coordinate is the organisation-level capacity to convert orientation into deliberate, legitimate and interdependent response.

The term includes more than dependency management.

It contains:

- choice;
- authority;
- mobilisation;
- coordination;
- and governed execution.

#### Improve

```text
Observe outcome
→ Evaluate feedback
→ Learn
→ Adapt
```

Improve is the organisation-level capacity to use consequence and experience to strengthen future orientation and response.

Improvement can include:

- confirmation;
- increased reliability;
- changed understanding;
- changed behaviour;
- capability development;
- capability retirement;
- or reconfiguration.

### 4.3 Cross-Cutting Conditions

The following do not form separate sequential stages:

- purpose;
- legitimacy;
- epistemic quality;
- evidence;
- provenance;
- authority;
- accountability;
- communication;
- control;
- ethics;
- legality;
- power;
- culture;
- trust;
- psychological safety;
- incentives;
- resources;
- time;
- technology;
- and organisational identity.

They affect the quality and responsible exercise of every transformation.

### 4.4 Memory as Continuity Infrastructure

Organisational memory has two roles.

First, it supplies prior experience, decisions, relationships, routines and knowledge to the current cycle.

Second, it retains what the current cycle produces.

Memory is therefore not merely a stage after action.

It is a continuity system that:

```text
supplies prior experience
        ↓
supports current orientation and response
        ↓
receives decisions, outcomes and learning
        ↓
changes future availability and interpretation
```

The future Organisational Memory, Reflection and Learning chapter will define this relationship fully.

### 4.5 Purpose as Direction and Evaluation Basis

Purpose shapes:

- which signals matter;
- which context is relevant;
- which knowledge is needed;
- which decisions are legitimate;
- which coordination is coherent;
- and which outcomes count as improvement.

Purpose must remain:

- explicit;
- communicable;
- contestable;
- legitimate;
- and revisable.

A highly coordinated and adaptive organisation pursuing an incoherent or harmful purpose is not automatically evidence of responsible Organisational Intelligence.

---

## 5. Chapters 1–5 Coverage Synthesis

### 5.1 OI-BOK-001 — Signals and Attention

#### Primary Ownership

Chapter 1 owns:

- event;
- data point;
- cue;
- signal;
- weak signal;
- noise;
- organisational attention;
- attention structures;
- attention episodes;
- and attentional debt.

#### Primary Transformation

```text
Occurrence
→ Capture
→ Recognition
→ Qualification
→ Routing
→ Attention
```

#### Contribution to OI

Chapter 1 establishes that:

> Organisational Intelligence begins with what the organisation is structurally capable of noticing.

Attention is organisationally allocated through:

- roles;
- rules;
- incentives;
- technologies;
- routines;
- reporting paths;
- and interfaces.

#### Boundary

Chapter 1 does not complete orientation.

Its process currently continues through contextualisation to orientation for explanatory continuity.

The final integration pass should clarify that Chapter 1 owns the path to **attended and routed signal**, while Chapters 2 and 3 own the additional work required to form orientation.

#### Forward Dependency

```text
Attended signal
→ Organisational Context
```

---

### 5.2 OI-BOK-002 — Organisational Context

#### Primary Ownership

Chapter 2 owns:

- organisational context;
- situation;
- contextual dimensions;
- temporal validity;
- context decay and drift;
- minimum sufficient context;
- evidence-bearing context;
- context gaps;
- and purpose-bound assembly.

#### Primary Transformation

```text
Define purpose
→ Identify required context
→ Retrieve candidate sources
→ Filter by relevance, authority, time and permission
→ Preserve provenance, uncertainty and disagreement
→ Assemble a bounded context view
```

#### Contribution to OI

Chapter 2 establishes that:

> Information becomes organisationally useful only when situated within the conditions that determine meaning, relevance, authority and appropriate use.

#### Boundary

Context is not:

- the same as knowledge;
- the same as organisational memory;
- the same as state;
- or the same as orientation.

Context supplies the conditions under which knowledge and interpretation become usable.

#### Forward Dependency

```text
Evidence-bearing context
→ Knowledge and expertise
→ Orientation
```

---

### 5.3 OI-BOK-003 — Knowledge and Expertise

#### Primary Ownership

Chapter 3 owns:

- organisational knowledge;
- knowing;
- expertise;
- expertise availability;
- expertise coordination;
- knowledge authority;
- expertise routing;
- transactive memory;
- transfer as recontextualisation;
- and expertise dependency.

#### Primary Transformation

```text
Define knowledge need
→ Identify required domains
→ Discover sources and expertise
→ Evaluate fit, authority, evidence and currency
→ Gain access
→ Translate into context
→ Integrate contributions
```

#### Contribution to OI

Chapter 3 establishes that:

> Knowledge contributes to Organisational Intelligence only where it can reach the situation, influence legitimate response and improve future availability.

#### Boundary

Chapter 3 owns knowledge availability and expertise integration.

It does not own:

- decision authority;
- complete organisational memory;
- or organisational learning.

The future memory and learning chapter will own retention, forgetting, reflective learning and institutional update.

#### Forward Dependency

```text
Context + available knowledge + coordinated expertise
→ Organisational orientation
→ Decision
```

---

### 5.4 OI-BOK-004 — Decision and Authority

#### Primary Ownership

Chapter 4 owns:

- issue;
- decision;
- recommendation;
- decision rights;
- formal and real authority;
- delegation;
- Decision Owner;
- decision-maker;
- approval;
- veto;
- action authority;
- accountability;
- deliberate non-action;
- decision record;
- decision-time context;
- contestability;
- and reversibility.

#### Primary Transformation

```text
Define the decision
→ Establish authority
→ Set scope and criteria
→ Assemble context, evidence and expertise
→ Generate alternatives
→ Elicit dissent
→ Select a decision route
→ Make and record the commitment
→ Authorise action
```

#### Contribution to OI

Chapter 4 establishes that:

> A decision is an attributable and authorised commitment, not merely an answer or recommendation.

#### Boundary

Chapter 4 owns the authorised commitment.

It does not own:

- dependency design;
- operational execution;
- or outcome evaluation.

Its later process steps point forward to Chapters 5–9 and should be treated as integration links rather than complete coverage.

#### Forward Dependency

```text
Authorised commitment
→ Shared commitment
→ Coordination
```

---

### 5.5 OI-BOK-005 — Coordination and Collective Action

#### Primary Ownership

Chapter 5 owns:

- dependency;
- interdependence;
- coordination;
- coordination mechanisms;
- accountability, predictability and common understanding as integrative conditions;
- shared commitment;
- collective action;
- roles;
- interfaces;
- handoffs;
- shared state;
- mutual adjustment;
- boundary coordination;
- coordination load;
- coordination debt;
- and coordination repair.

#### Primary Transformation

```text
Receive authorised decision
→ Translate into commitments
→ Map dependencies and outcomes
→ Allocate roles, resources and authority
→ Select coordination mechanisms
→ Establish shared state, interfaces and handoffs
→ Perform and monitor interdependent work
→ Repair and integrate
```

#### Contribution to OI

Chapter 5 establishes that:

> Communication, task assignment and activity become collective response only when interdependent contributions are connected and adjusted to the wider organisational system.

#### Boundary

Chapter 5 owns the coordination architecture and interaction conditions around collective work.

It does not fully own:

- action fidelity;
- operational reliability;
- failure recovery;
- operational safety;
- completion;
- or consequence production.

Those belong to Chapter 6.

#### Forward Dependency

```text
Coordinated collective action
→ Governed execution
```

---

## 6. Transition and Connection Map

### 6.1 Why the Transitions Matter

Each transition converts one organisational condition into another.

The quality of the destination cannot be inferred from the presence of the source.

### 6.2 Transition Register

| Transition | Conversion question | Primary owner | Current status |
|---|---|---|---|
| Event → Signal | What makes an occurrence potentially material? | Chapter 1 | Covered |
| Signal → Attention | How does it receive processing capacity? | Chapter 1 | Covered |
| Attention → Context | How does the signal gain organisational meaning? | Chapters 1–2 | Covered, boundary needs final wording |
| Context → Knowledge | Which understanding and expertise apply? | Chapters 2–3 | Covered |
| Knowledge → Orientation | How are context, evidence and expertise integrated into a usable organisational view? | Chapters 2–3 and final synthesis | Substantially covered; final synthesis required |
| Orientation → Decision | How does understanding become an authorised commitment? | Chapter 4 | Covered |
| Decision → Shared Commitment | How does the commitment become usable across actors? | Chapters 4–5 | Covered |
| Commitment → Coordination | How are dependencies, roles and mechanisms established? | Chapter 5 | Covered |
| Coordination → Execution | How is authorised work performed reliably? | Chapter 6 | Uncovered |
| Execution → Outcome | How do action and environment produce consequence? | Chapters 6–7 | Uncovered |
| Outcome → Feedback | How are consequences observed and evaluated? | Chapter 7 | Uncovered |
| Feedback → Learning | How are assumptions and future response revised? | Chapter 8 | Uncovered |
| Learning → Capability Change | How does learning become durable organisational capability? | Chapters 8–9 | Uncovered |
| Capability Change → Future Orientation and Response | How does adaptation change the next cycle? | Chapter 9 and final synthesis | Uncovered |

### 6.3 Connection Quality

The final BOK should treat connection quality as an explicit diagnostic dimension.

Candidate connection-quality questions include:

- Is the source condition visible?
- Is the conversion attributable?
- Are evidence and uncertainty preserved?
- Is authority appropriate?
- Can failure be detected?
- Can the transition be reconstructed?
- Does the receiving capability accept the output?
- Does the connection depend on one heroic person?
- Can later feedback modify the conversion?

Connection quality should not become one universal score before empirical validation.

---

## 7. Terminology and Construct Boundary Reconciliation

### 7.1 Attention and Orientation

**Attention** is the allocation of organisational processing capacity.

**Orientation** is the resulting sufficiently shared or aligned organisational view of:

- what is happening;
- why it matters;
- what remains uncertain;
- and what should shape response.

Attention is necessary.

It is not orientation.

### 7.2 Context and Knowledge

**Context** describes the conditions that determine meaning and appropriate use.

**Knowledge** describes understanding, know-how, judgement or justified belief capable of informing interpretation or action.

A policy’s effective period is context.

Understanding how to apply it under an unusual customer condition is knowledge or expertise.

### 7.3 Knowledge and Organisational Memory

**Knowledge** is current understanding or capability.

**Organisational memory** is the system through which experience, knowledge, decisions, relationships and routines are retained, located, reconstructed, forgotten and reused across time.

Memory may contain obsolete or incorrect knowledge.

Knowledge may exist without being durably retained.

### 7.4 Expertise and Authority

**Knowledge authority** concerns credibility regarding a claim or domain.

**Decision authority** concerns the right to commit the organisation.

**Action authority** concerns the right to execute the response.

They may reside in different actors.

### 7.5 Orientation and Common Understanding

**Orientation** is an organisation-level account of the situation and response conditions.

**Common understanding** is an integrative condition allowing relevant actors to coordinate their interdependent contributions.

A whole organisation can have a usable orientation while different teams retain local interpretations.

A coordination group needs only the common understanding relevant to its dependencies.

### 7.6 Decision Commitment and Shared Commitment

A **decision commitment** is the authoritative organisational commitment created by a decision.

A **shared commitment** is the sufficiently distributed recognition that the decision is effective and creates obligations for coordinated work.

The first is made under authority.

The second is established through translation, legitimacy, role and communication.

### 7.7 Coordination, Mobilisation and Execution

**Mobilise** is the operational capability within Coordinate.

It contains:

- coordination;
- resource and role mobilisation;
- and governed execution.

**Coordination** manages dependencies and integration among contributions.

**Execution** performs the authorised work.

Chapter 5 owns coordination.

Chapter 6 will complete Mobilise through execution and operational reliability.

### 7.8 Accountability

The BOK uses accountability in two related senses.

#### Governance Accountability

From Chapter 4:

- actor;
- forum;
- explanation;
- judgement;
- and consequence.

#### Coordination Accountability

From Chapter 5:

- visible contribution ownership;
- mutual expectations;
- and responsibility for dependency performance.

The final glossary should use the qualifiers:

- **governance accountability**
- and **coordination accountability**

where ambiguity is possible.

### 7.9 State, Shared State and Context

**State** is the current condition of an entity, activity, system or process.

**Shared state** is the purpose-bound coordination representation of relevant work and dependency state.

**Context** includes state plus:

- purpose;
- history;
- relationships;
- authority;
- evidence;
- and uncertainty.

### 7.10 Handoff Integrity

Handoff integrity belongs primarily to coordination.

The content required for integrity is inherited from:

- context;
- knowledge;
- decision;
- authority;
- and current state.

Chapter 5 should own the generic handoff definition.

Other chapters may define the content needed for a particular handoff.

### 7.11 Repair, Learning and Adaptation

**Repair** restores coherent operation in the current episode.

**Learning** revises understanding or future response through feedback.

**Adaptation** changes capability, structure, authority, resource or routine.

A successful repair is not automatically learning.

Repeated repair without system change is evidence of coordination or operational debt.

### 7.12 Outcome, Feedback and Evaluation

**Outcome** is a consequence.

**Feedback** is information about consequence in relation to:

- action;
- expectation;
- purpose;
- or environment.

**Evaluation** is the governed interpretation of outcome and process.

An outcome does not teach the organisation automatically.

### 7.13 Evidence and Provenance

Evidence and provenance are cross-cutting epistemic conditions.

They should not become a separate sequential capability.

They affect:

- attention qualification;
- context;
- knowledge;
- decision;
- execution;
- outcome evaluation;
- and learning.

### 7.14 Purpose and Governance

Purpose and governance act across the cycle.

They should not be reduced to a first step completed once.

### 7.15 Organisational Intelligence

Organisational Intelligence remains:

- emergent;
- organisation-level;
- persistent;
- collective;
- feedback-coupled;
- and sociotechnically instantiated.

It is not:

- a repository;
- a graph;
- a score;
- a person;
- a model;
- an Agent;
- a platform layer;
- or one outcome.

---

## 8. Cross-Chapter Overlap and Required Final Reconciliation

### 8.1 Signal-to-Orientation Overlap

Chapter 1 currently presents:

```text
Attention
→ Contextualisation
→ Orientation
```

Chapters 2 and 3 show that contextualisation and knowledge integration are substantive processes.

**Final reconciliation action:**

Chapter 1 should end its owned process at attention and route forward explicitly to Chapters 2 and 3.

### 8.2 Context-to-Orientation Overlap

Chapter 2 occasionally speaks as though context assembly may produce orientation.

Chapter 3 establishes that relevant knowledge and expertise are also required.

**Final reconciliation action:**

Use:

```text
Attended signal
+ evidence-bearing context
+ available knowledge and expertise
+ interpretation
= orientation potential
```

Do not present the expression as a measurement formula.

### 8.3 Memory Ownership

Memory appears in Chapters 1–3 as:

- prior experience;
- historical context;
- knowledge retention;
- and transactive memory.

It is not yet treated as a full organisation-level continuity system.

**Roadmap decision:**

Chapter 8 will own Organisational Memory, Reflection and Learning.

Earlier chapters will retain only the memory concepts necessary for their local argument and refer forward for the full model.

### 8.4 Authority Across Chapters

Authority appears in:

- context;
- expertise;
- decision;
- coordination;
- and future execution.

**Final reconciliation action:**

Chapter 4 remains the semantic owner of:

- decision rights;
- delegation;
- approval;
- veto;
- decision authority;
- action authority;
- and governance accountability.

Other chapters should apply rather than redefine those concepts.

### 8.5 Commitment Across Chapters

Chapter 4 creates an organisational commitment.

Chapter 5 distributes that commitment into coordinated obligations.

**Final reconciliation action:**

Preserve:

```text
Decision commitment
→ Shared commitment
→ Coordinated contribution
```

### 8.6 Coordination and Execution

Chapter 5 includes performing and monitoring interdependent work.

Chapter 6 will examine operational execution in depth.

**Final reconciliation action:**

Chapter 5 should own:

- dependency design;
- coordination mechanisms;
- shared state;
- handoffs;
- and integration.

Chapter 6 should own:

- action fidelity;
- operational control;
- reliability;
- error;
- recovery;
- resilience;
- and completion.

### 8.7 Forward-Looking Learning Language

Chapters 1–5 all include propositions about improving future capability.

This maintains connection to the complete OI loop.

It should not be treated as equivalent to covering Learn or Adapt.

### 8.8 Human–AI Repetition

Every chapter contains a human–AI section.

The repetition is useful during development because AI creates different risks in each domain.

The final BOK should consolidate cross-cutting human–AI principles in Chapter 10 while retaining domain-specific detail in Chapters 1–9.

### 8.9 SMB Repetition

Each chapter includes an SMB interpretation.

The final BOK should retain those sections because they make the research operational.

Chapter 10 should also provide one integrated SMB OI profile showing how the complete cycle may operate proportionately without enterprise bureaucracy.

### 8.10 Propositions and Failure Modes

The first five chapters contain:

- 80 propositions;
- and 139 named failure modes.

Several are local versions of the same system pattern.

Examples include:

- visibility without ownership;
- knowledge without action;
- action without authority;
- coordination without purpose;
- and repair without learning.

**Completion requirement:**

The final registers must:

- preserve chapter provenance;
- merge genuine duplicates;
- distinguish local and system-level failure;
- and avoid presenting every phrase as an independent construct.

---

## 9. Coverage Against the Existing Capability Map

The Project OI Capability Map contains twelve capability domains.

### 9.1 Coverage Matrix

| Capability-map domain | Current BOK coverage | Disposition |
|---|---|---|
| 4.1 Perception and Signal Detection | Chapter 1 | Covered |
| 4.2 Context and Sensemaking | Chapter 2, with orientation integration across Chapters 2–3 | Covered, final synthesis needed |
| 4.3 Knowledge Creation and Validation | Chapter 3 | Substantially covered |
| 4.4 Organisational Memory and Retrieval | Partial in Chapters 2–3 | Requires Chapter 8 |
| 4.5 Reasoning and Judgement | Chapters 3–4 | Substantially covered |
| 4.6 Decision-Making and Commitment | Chapter 4 | Covered |
| 4.7 Coordination and Orchestration | Chapter 5 | Covered |
| 4.8 Governed Action | Partial in Chapters 4–5 | Requires Chapter 6 |
| 4.9 Outcome Observation and Evaluation | Forward references only | Requires Chapter 7 |
| 4.10 Reflection and Learning | Forward references only | Requires Chapter 8 |
| 4.11 Capability Development | Propositions and implications only | Requires Chapter 9 |
| 4.12 Adaptation and Reconfiguration | Largely uncovered | Requires Chapter 9 |

### 9.2 Cross-Cutting Enablers

The capability map lists:

- purpose and goals;
- culture;
- trust;
- governance;
- language;
- technology;
- incentives;
- time;
- and power.

Chapters 1–5 address many of these locally.

They require final integrated treatment in Chapter 10.

### 9.3 System-Level Failure Patterns

The capability map identifies:

- broken feedback loops;
- context loss;
- memory without use;
- action without judgement;
- learning without institutionalisation;
- coordination without purpose;
- governance without intelligence;
- knowledge without action;
- and adaptation without coherence.

The chapter sequence now supplies detailed mechanisms for the first half of these patterns.

The remaining chapters must close the feedback, learning, institutionalisation and adaptation gaps.

---

## 10. Materially Uncovered Domains

### 10.1 Execution and Operational Reliability

The BOK has not yet fully explained how authorised and coordinated work becomes reliable operation.

Required subjects include:

- action fidelity;
- task and Workflow execution;
- operational state;
- control;
- observability;
- error and exception;
- retries;
- idempotency;
- recovery;
- compensation;
- reversibility;
- safety;
- resilience;
- human intervention;
- and completion.

### 10.2 Outcomes, Feedback and Evaluation

The BOK has not yet fully explained:

- what counts as an outcome;
- intended and unintended consequences;
- immediate and delayed effects;
- stakeholder outcomes;
- measurement;
- observability;
- attribution and contribution;
- feedback delay and distortion;
- metric gaming;
- evaluation;
- and process-versus-outcome review.

### 10.3 Organisational Memory, Reflection and Learning

The BOK has not yet fully explained:

- acquisition;
- retention;
- retrieval;
- reconstruction;
- forgetting;
- supersession;
- decision-time memory;
- reflection;
- single-loop and double-loop learning;
- learning from success;
- learning from near misses;
- blame and inquiry;
- and how learning changes future understanding and response.

### 10.4 Capability Development and Adaptation

The BOK has not yet fully explained:

- capability formation;
- institutionalisation;
- capability distribution;
- training through work;
- routine development;
- capability decay;
- capability retirement;
- exploration and exploitation;
- absorptive capacity;
- dynamic capabilities;
- experimentation;
- resilience;
- reconfiguration;
- and adaptation without loss of coherence.

### 10.5 Integrated and Responsible Organisational Intelligence

The final synthesis must still integrate:

- the complete definition;
- construct boundaries;
- unit of analysis;
- purpose;
- governance;
- epistemic quality;
- authority;
- accountability;
- ethics;
- power;
- measurement;
- enabling conditions;
- outcomes;
- human–AI participation;
- counterexamples;
- and the research agenda.

These subjects do not justify several additional open-ended chapters.

They belong in one final synthesis chapter supported by the consolidation registers.

---

## 11. Locked Remaining Chapter List

## OI-BOK-006 — Execution and Operational Reliability

### Governing Question

> **How does an organisation perform authorised work reliably while managing variation, failure, safety, recovery and operational control?**

### Primary Capability

**Mobilise**, completing the operational half left open by Chapter 5.

### Required Scope

- action and execution;
- fidelity between decision and operation;
- operational state;
- work completion;
- reliability;
- exceptions;
- failure modes;
- recovery;
- resilience;
- control;
- reversibility and compensation;
- safety;
- human intervention;
- automation;
- AI and Agent execution;
- and outcome production.

### Explicit Exclusions

- detailed outcome evaluation;
- organisational learning;
- and capability adaptation.

Those belong to Chapters 7–9.

---

## OI-BOK-007 — Outcomes, Feedback and Evaluation

### Governing Question

> **How does an organisation observe and evaluate the consequences of its response without confusing activity, metrics, implementation and outcome?**

### Primary Function

The bridge from **Mobilise** to **Improve**.

### Required Scope

- outcome;
- output;
- effect;
- impact;
- intended and unintended consequence;
- leading and lagging indicators;
- observability;
- attribution and contribution;
- counterfactual limits;
- delayed feedback;
- stakeholder perspective;
- metric design;
- Goodhart-type distortion;
- process, implementation and outcome evaluation;
- and feedback quality.

### Explicit Exclusion

The chapter will not own durable organisational learning or capability change.

---

## OI-BOK-008 — Organisational Memory, Reflection and Learning

### Governing Question

> **How does an organisation preserve, reconstruct and reinterpret experience so that consequences can change future understanding and response?**

### Primary Capability

**Learn**

### Required Scope

- organisational memory;
- memory reservoirs;
- acquisition;
- retention;
- retrieval;
- reconstruction;
- forgetting;
- supersession;
- decision-time context;
- reflection;
- review;
- single-loop learning;
- double-loop learning;
- learning from success and failure;
- near misses;
- blame and inquiry;
- knowledge update;
- routine update;
- and learning persistence.

### Why Memory and Learning Are Combined

Memory enables learning to persist.

Learning determines what memory should be:

- revised;
- strengthened;
- contextualised;
- or retired.

Treating them separately would duplicate the feedback-to-future-capability transition.

---

## OI-BOK-009 — Capability Development and Adaptation

### Governing Question

> **How does organisational learning become durable capability, and how does the organisation develop, retire or reconfigure that capability as conditions change?**

### Primary Capability

**Adapt**

### Required Scope

- institutionalisation;
- capability formation;
- capability distribution;
- skill and practice development;
- routines;
- tools and structures;
- capability measurement;
- fragility and resilience;
- exploration and exploitation;
- absorptive capacity;
- path dependence;
- dynamic capabilities;
- experimentation;
- capability decay;
- retirement;
- resource reallocation;
- and coherent reconfiguration.

### Explicit Boundary

Adaptation is not change volume.

It is evidence-linked change to organisational capacity that preserves sufficient purpose, identity and coherence.

---

## OI-BOK-010 — Integrated and Responsible Organisational Intelligence

### Governing Question

> **What is the complete Project OI construct, how can it be observed responsibly, and what distinguishes it from adjacent concepts and superficially intelligent organisational behaviour?**

### Function

Final synthesis chapter.

It introduces no new operational stage.

### Required Scope

- final short and extended definition;
- Orient–Coordinate–Improve;
- Sense–Know–Choose–Mobilise–Learn–Adapt;
- connection quality;
- construct boundaries;
- unit and level of analysis;
- persistence and institutionalisation;
- purpose;
- governance;
- evidence quality;
- authority;
- accountability;
- ethics and legality;
- power;
- enabling and conditioning factors;
- outcomes;
- observable evidence;
- measurement principles;
- human–AI organisation;
- responsible autonomy;
- counterexamples;
- construct-validity expectations;
- limitations;
- and research agenda.

### Measurement Boundary

Chapter 10 may define:

- capability dimensions;
- indicators;
- evidence categories;
- and assessment principles.

It must not introduce a single maturity score without empirical validation.

---

## 12. BOK Completion Package

Completing Chapter 10 will not, by itself, complete the Body of Knowledge.

The following finite package is required.

### 12.1 Consolidated Glossary

**Artefact:** `OI-BOK-GLO-001`

Purpose:

- provide one preferred definition for material Project OI terms;
- identify the chapter that owns each term;
- preserve adjacent-term distinctions;
- and mark working terms that are not established constructs.

### 12.2 Consolidated Proposition and Evidence Register

**Artefact:** `OI-BOK-PROP-001`

For every proposition:

- proposition ID;
- current wording;
- source chapter;
- theoretical basis;
- evidence type;
- confidence;
- overlap;
- challenge;
- and status.

Statuses should include:

- source-supported synthesis;
- Project OI working proposition;
- needs refinement;
- duplicate;
- deferred;
- or rejected.

### 12.3 Failure Mode, Quality and Indicator Index

**Artefact:** `OI-BOK-DIAG-001`

It should consolidate:

- failure modes;
- quality dimensions;
- observable indicators;
- and system-level patterns.

It must preserve chapter provenance while merging genuine duplicates.

### 12.4 Cross-Chapter Traceability Matrix

**Artefact:** `OI-BOK-TRACE-001`

It should connect:

```text
OI transformation
→ operational capability
→ chapter
→ construct
→ process
→ proposition
→ evidence
→ failure mode
→ indicator
→ open question
```

### 12.5 Research Limitations and Open Questions Register

**Artefact:** `OI-BOK-OPEN-001`

It should distinguish:

- construct questions;
- empirical questions;
- measurement questions;
- ethical questions;
- AI-era questions;
- and future field-research needs.

### 12.6 BOK Index and Source Manifest

**Artefact:** `OI-BOK-INDEX-001`

It should record:

- chapter versions;
- status;
- source digests;
- dependencies;
- supersession;
- and completion state.

### 12.7 Construct-Validity and Adversarial Review

**Artefact:** `OI-BOK-REVIEW-001`

The review should test:

- novelty overclaim;
- construct inflation;
- circularity;
- level-of-analysis confusion;
- capability overlap;
- outcome contamination;
- normative ambiguity;
- measurement feasibility;
- human–AI overreach;
- and applicability to SMBs.

### 12.8 Completion Record

**Artefact:** `OI-BOK-RELEASE-001`

It should state:

- what has been completed;
- what remains unvalidated;
- accepted terminology;
- known limitations;
- deferred empirical work;
- and the exact downstream work now permitted.

---

## 13. Definition of BOK Completion

The Project OI Body of Knowledge is complete at its first coherent release when all of the following are true.

### 13.1 Chapter Completion

- OI-BOK-001 through OI-BOK-010 exist.
- Each chapter has passed a source and internal-consistency review.
- Each chapter uses the final glossary or has an explicit exception.
- Each chapter states its boundaries and limitations.

### 13.2 Model Completion

- The final definition is stable enough for one release.
- Orient, Coordinate and Improve are reconciled.
- Sense, Know, Choose, Mobilise, Learn and Adapt are reconciled.
- The complete cycle and connection mechanisms are explicit.
- Cross-cutting conditions are distinguished from stages.

### 13.3 Terminology Completion

- One glossary owns the definitions.
- Context, knowledge, memory, orientation, decision, coordination, execution, outcome, feedback, learning, capability and adaptation are distinguished.
- Working terms are labelled.
- Duplicated terms are removed or scoped.

### 13.4 Proposition Completion

- All chapter propositions are registered.
- Duplicates are reconciled.
- Evidence and confidence are visible.
- No working proposition is presented as a validated law.

### 13.5 Diagnostic Completion

- Failure modes are consolidated.
- Quality dimensions are reconciled.
- Observable indicators are linked to constructs.
- System-level failure patterns are explicit.

### 13.6 Evidence Completion

- Primary sources are traceable.
- Evidence type and limits are visible.
- AI-era claims are time- and setting-qualified.
- Source gaps are explicit.

### 13.7 Construct Boundary Completion

The BOK distinguishes Organisational Intelligence from:

- individual intelligence;
- collective intelligence;
- organisational learning;
- knowledge management;
- coordination;
- dynamic capability;
- information processing;
- culture;
- technology maturity;
- performance;
- viability;
- and AI capability.

### 13.8 Responsible-Use Completion

The BOK addresses:

- purpose;
- legitimacy;
- ethics;
- authority;
- accountability;
- power;
- control;
- contestability;
- and human–AI participation.

### 13.9 Review Completion

- The adversarial review is complete.
- Material contradictions are resolved or explicitly retained.
- Known limitations are published.
- The release record is approved by the programme owner.

---

## 14. What BOK Completion Does Not Mean

Completion of the first coherent BOK release does not mean:

- Organisational Intelligence has been empirically validated as a new construct;
- all relevant literature has been exhausted;
- a causal theory has been proven;
- a maturity model is validated;
- every indicator is measurable;
- every proposition is confirmed;
- the product architecture should automatically change;
- the software implements the BOK;
- the public blog series is complete;
- or field research is no longer required.

It means:

> **Project OI has produced a coherent, bounded, evidence-traceable and internally reconciled working Body of Knowledge that can support empirical testing, product reconciliation and public synthesis without relying on contradictory working notes.**

---

## 15. Locked Work Sequence

### Phase 1 — Complete Operational Coverage

1. OI-BOK-006 — Execution and Operational Reliability
2. OI-BOK-007 — Outcomes, Feedback and Evaluation
3. OI-BOK-008 — Organisational Memory, Reflection and Learning
4. OI-BOK-009 — Capability Development and Adaptation

### Phase 2 — Consolidate the Registers

5. Consolidated Glossary
6. Proposition and Evidence Register
7. Failure Mode, Quality and Indicator Index
8. Cross-Chapter Traceability Matrix
9. Limitations and Open Questions Register

### Phase 3 — Write the Final Synthesis

10. OI-BOK-010 — Integrated and Responsible Organisational Intelligence

### Phase 4 — Review and Release

11. BOK Index and Source Manifest
12. Construct-Validity and Adversarial Review
13. Corrections and final cross-chapter editorial pass
14. BOK Completion Record

### Phase 5 — Post-BOK Work

Only after the Completion Record:

- consolidated Project OI-to-product architecture reconciliation;
- product implication consolidation;
- implementation pattern review;
- blog editorial gate and possible publication;
- field-test and interview programme;
- measurement research;
- and empirical validation design.

---

## 16. Workstream Rules During BOK Completion

### 16.1 Blog Work Remains Paused

Do not create:

- new public articles;
- article publication packages;
- illustration programmes;
- or social launch material.

Existing Blog 01–04 assets remain frozen.

### 16.2 Product Implications Remain Paused

Do not create a new OI-REF entry for every chapter.

Existing implications remain research inputs for the final architecture reconciliation.

### 16.3 Implementation Patterns Remain Paused

Do not create a new OI-PAT artefact for every chapter.

A pattern may be created only where the BOK cannot be clarified adequately without testing the mechanism.

### 16.4 Architecture Reconciliation Remains Deferred

Do not:

- amend the canonical architecture;
- create new platform primitives;
- allocate ADRs;
- or turn BOK terms into product contracts.

### 16.5 No Automatic Chapter Expansion

A new chapter outside OI-BOK-006 through OI-BOK-010 requires:

- a demonstrated ownership gap;
- evidence that the material cannot be combined coherently;
- and an explicit roadmap amendment.

### 16.6 Research May Expand Within a Locked Chapter

Additional literature may be used where required to:

- test a chapter;
- resolve contradiction;
- or support a missing domain.

The chapter boundary remains fixed unless evidence disproves it.

---

## 17. Chapter Production Standard for OI-BOK-006 through OI-BOK-009

Each remaining domain chapter should include:

1. purpose and governing question;
2. core finding;
3. working definitions;
4. distinctions from adjacent constructs;
5. theoretical foundations;
6. process or mechanism;
7. organisational and human–AI implications;
8. failure modes;
9. quality dimensions;
10. proportionate operating modes;
11. SMB interpretation;
12. Project OI propositions;
13. observable indicators;
14. practical principles;
15. relationship to Organisational Intelligence;
16. research limitations;
17. and source register.

### 17.1 Reuse Existing Definitions

Do not redefine terms already owned by another chapter.

Use cross-references.

### 17.2 Do Not Fully Repeat the OI Cycle

Each chapter should state its local position in the cycle and avoid re-explaining the complete model.

### 17.3 Separate Source Findings From Synthesis

The chapter should distinguish:

- established source claims;
- Project OI synthesis;
- and working propositions.

### 17.4 Preserve Epistemic Modesty

Do not treat a review, experiment or single organisational setting as universal evidence.

### 17.5 Keep the Future Product Out

Product examples may illustrate.

They must not become the chapter’s organising structure.

---

## 18. Consolidation Priorities

### 18.1 Proposition Reduction

The 80 current propositions should not simply be joined to future propositions.

The final register should cluster them into higher-order families:

1. attention and relevance;
2. context and epistemic integrity;
3. knowledge and expertise availability;
4. decision and authority;
5. coordination and mobilisation;
6. execution and operational reliability;
7. feedback and evaluation;
8. memory and learning;
9. capability and adaptation;
10. responsible human–AI organisation;
11. connection quality.

### 18.2 Failure Mode Taxonomy

Failure modes should be organised into:

- capability failure;
- transition failure;
- governance failure;
- epistemic failure;
- authority failure;
- operational failure;
- feedback failure;
- persistence failure;
- and system-level failure.

### 18.3 Indicator Discipline

The final BOK should distinguish:

- direct evidence of capability;
- enabling conditions;
- outcome measures;
- process measures;
- and risk signals.

Trust, leadership, data maturity and technology use should not be treated as direct proof of OI.

### 18.4 Working-Term Discipline

Current working terms include:

- attentional debt;
- context decay;
- context drift;
- context laundering;
- minimum sufficient context;
- evidence-bearing context;
- expertise routing;
- expertise dependency;
- shadow authority;
- handoff integrity;
- coordination load;
- and coordination debt.

The final glossary must state:

- whether each term is retained;
- whether an established analogue exists;
- and what evidence would be required to operationalise it.

---

## 19. Risks to the Completion Programme

### 19.1 Research Rabbit Holing

Risk:

Every chapter reveals another adjacent discipline and creates pressure for a new chapter.

Control:

Use the locked ownership map and place adjacent material in:

- the owning chapter;
- Chapter 10;
- an appendix;
- or the open-questions register.

### 19.2 Construct Inflation

Risk:

Every useful concept becomes part of the definition of Organisational Intelligence.

Control:

Retain a parsimonious core:

```text
Orient
→ Coordinate
→ Improve
```

Treat most constructs as:

- mechanisms;
- conditions;
- capabilities;
- or outcomes.

### 19.3 Product Bias

Risk:

The BOK evolves to justify the product architecture.

Control:

Complete the BOK before architecture reconciliation.

### 19.4 Publication Bias

Risk:

Public article theses shape chapter scope.

Control:

Keep blog work paused.

### 19.5 Framework Proliferation

Risk:

Each chapter creates a new model that competes with the overall cycle.

Control:

Local chapter models must map into the six operational capabilities and three transformations.

### 19.6 Measurement Prematurity

Risk:

Candidate indicators become a maturity score before construct validation.

Control:

Preserve indicators as evidence categories and hypotheses.

### 19.7 AI Exceptionalism

Risk:

AI receives a separate theory for every domain.

Control:

Treat AI as a participant whose capabilities, authority and failure modes must be governed through the same organisational model, with specific additions where evidence requires them.

### 19.8 Endless Revision

Risk:

Completed chapters are repeatedly reopened before later evidence requires it.

Control:

Freeze Chapters 1–5 until the final cross-chapter editorial pass.

---

## 20. Locked Concept Ownership Map

| Construct family | Owning chapter |
|---|---|
| Event, cue, signal, attention | OI-BOK-001 |
| Context, situation, temporal validity, context assembly | OI-BOK-002 |
| Knowledge, expertise, knowledge authority, expertise availability | OI-BOK-003 |
| Decision, decision rights, authority, delegation, approval, accountability | OI-BOK-004 |
| Dependency, coordination, shared commitment, roles, handoffs, shared state | OI-BOK-005 |
| Action, execution, operational control, reliability, failure and recovery | OI-BOK-006 |
| Output, outcome, impact, feedback, evaluation and attribution | OI-BOK-007 |
| Organisational memory, reflection, learning and forgetting | OI-BOK-008 |
| Capability, institutionalisation, development, retirement and adaptation | OI-BOK-009 |
| Integrated OI construct, purpose, governance, ethics, measurement and human–AI organisation | OI-BOK-010 |

This map governs term ownership during the remaining work.

---

## 21. Roadmap Decisions

The following decisions are locked by this artefact.

### RD-001 — Retain the Three Transformations

```text
Orient
→ Coordinate
→ Improve
```

### RD-002 — Retain the Six Operational Capabilities

```text
Sense
Know
Choose
Mobilise
Learn
Adapt
```

### RD-003 — Treat Contextualisation as a Bridge

Context remains a substantive chapter and mechanism, not a seventh operational capability.

### RD-004 — Treat Outcome and Feedback as a Bridge

Outcome is consequence.

Feedback and evaluation connect Mobilise to Learn.

### RD-005 — Combine Memory and Learning

Organisational Memory, Reflection and Learning form one remaining chapter.

### RD-006 — Combine Capability Development and Adaptation

Institutionalisation, development, retirement and reconfiguration form one remaining chapter.

### RD-007 — Use One Final Integrated Chapter

Purpose, governance, ethics, measurement and human–AI integration belong in Chapter 10 rather than several additional domain chapters.

### RD-008 — Lock the BOK at Ten Chapters

No eleventh substantive chapter without roadmap amendment.

### RD-009 — Pause Companion Production

Blogs, product implications, patterns and architecture reconciliation remain paused.

### RD-010 — Define Completion as Coherent Synthesis, Not Validation

The first complete BOK release is a bounded and evidence-traceable working synthesis.

It is not a validated general theory.

---

## 22. Next Active Artefact

The next active artefact is:

> **OI-BOK-006 — Execution and Operational Reliability v0.1**

Its governing question is:

> **How does an organisation perform authorised work reliably while managing variation, failure, safety, recovery and operational control?**

The chapter should begin only from the scope locked in Section 11.

No companion blog, product implication reference or implementation pattern should be created alongside it.

---

## 23. Editorial Guardrail

> **The remaining programme exists to close the Organisational Intelligence feedback loop, not to create an unlimited encyclopaedia of organisational theory. Complete the locked ten-chapter model, consolidate its terms and evidence, and defer product, publication and empirical expansion until the Body of Knowledge is coherent as a whole.**
