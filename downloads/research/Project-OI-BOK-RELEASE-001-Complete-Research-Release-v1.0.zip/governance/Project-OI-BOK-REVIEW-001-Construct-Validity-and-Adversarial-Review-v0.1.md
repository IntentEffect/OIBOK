# Project OI Body of Knowledge

# Construct-Validity and Adversarial Review

**Artefact ID:** OI-BOK-REVIEW-001  
**Version:** 0.1  
**Status:** Completed adversarial review; correction phase authorised  
**Review subject:** OI-BOK-001 through OI-BOK-010 and the complete consolidation set  
**Controlled inputs:** OI-BOK-SYN-001, GLO-001, PROP-001, DIAG-001, TRACE-001, OPEN-001 and INDEX-001  
**Prior challenge baseline:** Project OI Conceptual Challenge and Construct Boundary Review v0.1  
**External verification scope:** Targeted verification of current 2026 AI, Agent and standards sources; not a complete independent replication of the full bibliography  
**Review date:** 15 August 2026  
**Release verdict:** CONDITIONAL PASS TO CORRECTION PHASE  
**Canonical status:** Not canonical  
**Empirical status:** Literature-grounded working synthesis; not field validated  
**Measurement status:** Not a validated instrument, maturity model or score  
**Product and architecture status:** Remain deferred  
**Blog status:** Remains paused

---

## 1. Purpose

This review attempts to break the first complete Project OI Body of Knowledge before it is released.

It does not ask whether the corpus is:

- impressive;
- comprehensive;
- internally elaborate;
- or useful as a design vocabulary.

It asks whether the proposed construct survives challenge concerning:

- distinctiveness;
- parsimony;
- circularity;
- level of analysis;
- causal and temporal mechanism;
- evidence and measurement;
- responsible-use boundaries;
- power and stakeholder representation;
- AI exceptionalism and evidence expiry;
- SMB applicability;
- source integrity;
- and independence from the product programme that developed beside it.

The review has authority to:

- reject or narrow a working term;
- merge propositions;
- change a boundary;
- identify a release blocker;
- preserve a contradiction explicitly;
- and require source-controlled correction.

It does not create a new chapter or alternative theory.

---

## 2. Executive Verdict

### 2.1 Overall Decision

> **The BOK receives a conditional pass to a bounded correction phase. It is coherent enough to retain, but it is not ready for a formal v1.0 release in its current form.**

The review does **not** recommend:

- abandoning the construct;
- reopening the chapter roadmap;
- adding further substantive chapters;
- replacing the three transformations;
- replacing the six operational capabilities;
- creating a maturity score;
- or beginning product-architecture reconciliation.

The review does require correction before release.

### 2.2 Why the Construct Survives

The BOK has succeeded in separating several distinctions that often collapse in organisational and AI discourse:

```text
Information
        ≠
Context
        ≠
Knowledge
        ≠
Orientation
        ≠
Recommendation
        ≠
Decision
        ≠
Coordination
        ≠
Execution
        ≠
Outcome
        ≠
Feedback
        ≠
Learning
        ≠
Capability
        ≠
Adaptation
```

It also avoids defining Organisational Intelligence by:

- favourable outcome;
- technology ownership;
- document quantity;
- AI performance;
- or one intelligent participant.

The strongest contribution is still not one novel component.

It is the proposed integration and traceability of:

```text
Orientation
→ Authorised collective response
→ Consequence and evaluation
→ Persistent learning
→ Capability change
```

### 2.3 Why Release Is Blocked

Five categories of release blocker remain:

1. **The final chapter under-represents the explicit Organisational Intelligence lineage.**
2. **Product and editorial material remains inside Chapters 1–3.**
3. **Chapter metadata contradicts the final capability model.**
4. **A current AI study uses the working-paper sample size while citing the final publication.**
5. **A current software-development study has an incorrect author list.**

These are repairable.

They do not require additional theory chapters.

### 2.4 Finding Distribution

| Review result | Count |
| --- | --- |
| Release blockers | 5 |
| Major findings | 18 |
| Moderate findings | 9 |
| Minor findings | 2 |
| Accepted tensions | 5 |
| Elements that survived challenge | 5 |

The complete finding register contains **44 findings**, of which **23 are release-gated**.

---

## 3. Review Method

### 3.1 Internal Corpus Review

The review examined:

- ten substantive chapters;
- the Chapters 1–5 synthesis and roadmap;
- the 429-term glossary;
- the 182-proposition evidence register;
- the 437-failure-mode diagnostic index;
- the 14-transition traceability model;
- the 28 integrated open questions;
- the BOK index and source manifest;
- the earlier construct-boundary review;
- the explicit Organisational Intelligence literature review;
- and the intellectual-lineage map.

### 3.2 Adversarial Tests

The review applied the following tests.

#### Construct Test

Does OI identify a phenomenon not exhausted by adjacent constructs?

#### Parsimony Test

Does the model include more constructs than necessary?

#### Circularity Test

Can OI be observed without defining it through the outcome it is meant to explain?

#### Level Test

Can evidence from people, teams, systems and firms be attributed to the correct organisational unit?

#### Mechanism Test

Are the proposed transitions logical dependencies, empirical mechanisms or merely a useful sequence?

#### Measurement Test

Can the construct be operationalised without weak proxies, one score or self-confirming evidence?

#### Normative Test

Does the model distinguish descriptive capability from legitimate and responsible exercise without making harm irrelevant?

#### Power Test

Whose signal, knowledge, authority, outcome and memory become organisational?

#### AI Test

Are AI claims current, task-specific, provider-sensitive and organisationally integrated?

#### SMB Test

Can the model operate proportionately outside large-enterprise bureaucracy?

#### Independence Test

Has the research remained separate from the product and publication programme?

### 3.3 Targeted Current-Source Verification

The review conducted a targeted primary-source check of recent 2026 material that could have changed after the original chapter drafting.

It did not reverify all 283 provisionally normalised sources.

---

## 4. Release Decision Matrix

| Review dimension | Decision | Release implication |
| --- | --- | --- |
| Core definition | Conditional pass | Retain, with clarification of relevance, collective response, Improve and persistence |
| Three transformations | Pass | Retain Orient, Coordinate and Improve |
| Six operational capabilities | Conditional pass | Retain as an operational model, not a validated ontology or factor structure |
| Contextualise and Orientation | Conditional pass | Retain, with stronger recurring-process and boundary wording |
| Connection Quality | Major narrowing required | Retain as a research hypothesis, not a constitutive requirement or score |
| Unit of analysis | Major correction required | Add a mandatory claim-boundary and multilevel evidence protocol |
| Causal mechanism | Accepted tension | Retain as proposed feedback-coupled mechanism |
| Measurement | Not ready as instrument | Use bounded claims and evidence portfolios only |
| Responsible exercise | Pass with guardrail | One descriptive construct plus mandatory responsible-use reporting for consequential application |
| Power and representation | Major limitation | Strengthen source and research boundary |
| AI integration | Conditional pass | Reverify current sources and preserve evidence-type and expiry controls |
| SMB applicability | Unvalidated | Preserve as an application hypothesis and post-BOK field priority |
| Product independence | Fail in Chapters 1–3 | Remove product and editorial residue |
| Source integrity | Fail pending correction | Correct known factual and bibliographic errors and complete one house-style review |
| Additional chapters | Not required | Proceed to corrections and release record |

---

## 5. What Survived Challenge

### 5.1 The Short Construct Boundary

The short definition is still stronger than the earlier comprehensive definition because it does not try to place:

- attention;
- context;
- warrant;
- authority;
- action;
- memory;
- learning;
- adaptation;
- governance;
- ethics;
- people;
- and technology

inside one sentence.

### 5.2 The Layered Model

The current architecture is defensible:

```text
Core construct
        ↓
Three higher-order transformations
        ↓
Six operational capabilities
        ↓
Connective mechanisms and integrated states
        ↓
Quality, governance and responsible-use conditions
        ↓
Outcomes and evidence
```

### 5.3 Capability Is Not Outcome

The BOK consistently resists defining capability through one favourable result.

### 5.4 One Construct, Responsible Exercise

The decision not to create two separate OI constructs survives review.

### 5.5 No Single Score

The current evidence does not support one numerical maturity model.

### 5.6 No Additional Chapter

The material gaps found by the review concern:

- correction;
- lineage;
- boundaries;
- evidence;
- and release discipline.

They do not justify Chapter 11.

---

## 6. Release Blockers

### 6.1 Explicit OI Lineage Must Enter the Final Chapter

The internal explicit-literature review already establishes that Project OI cannot claim originality for:

- organisation-level intelligence;
- distributed people-and-system intelligence;
- knowledge creation and application;
- human–machine intelligence;
- learning and memory;
- mission-directed mobilisation;
- adaptation;
- or emergence through organisational capabilities.

The closest predecessors are already identified:

- Matsuda for early sociotechnical architecture;
- Choo for the process sequence;
- Albrecht for an accessible capability account;
- and Kolbjørnsrud for an AI-era organisational design.

Chapter 10 must show this lineage directly rather than relying on an internal source readers may never see.

### 6.2 Product and Editorial Residue Must Leave the BOK

OI-BOK-002 and OI-BOK-003 contain named product-implication sections and now-obsolete article and companion-output plans.

The final BOK cannot claim product independence while retaining those sections.

### 6.3 Metadata Must Match the Final Model

A reader should not encounter:

- Decide;
- Govern;
- Align;
- or Integrate

as though they were current operational capabilities when Chapter 10 has locked:

```text
Sense
Know
Choose
Mobilise
Learn
Adapt
```

### 6.4 Current AI Source Errors Must Be Corrected

The two detected factual and bibliographic errors are concrete release blockers.

They also demonstrate why the 18 time-sensitive sources need an explicit currency review.

---

## 7. Construct-Validity Review

### 7.1 Distinctiveness

The construct remains at risk of overlapping with:

- the Knowing Organisation;
- collective intelligence;
- organisational learning;
- organisational information processing;
- dynamic capabilities;
- resilience;
- and organisational effectiveness.

The current defensible distinction is:

> **Project OI concerns a persistent organisation-level capacity connecting orientation, authorised collective response and feedback-driven improvement across repeated situations and time.**

That distinction is plausible.

It is not yet proven.

### 7.2 Parsimony

The three transformations remain parsimonious.

The extended glossary and diagnostic system do not.

The release should separate the theory readers need from the research registers researchers may consult.

### 7.3 Unit and Emergence

The focal-unit definition needs a stricter claim protocol.

A team, firm and ecosystem can all be investigated through Project OI.

They should not be treated as interchangeable levels.

### 7.4 Persistence

Persistence is a useful boundary from:

- individual intelligence;
- episodic collective intelligence;
- and heroic intervention.

It requires an evidence threshold.

### 7.5 Connection Quality

Connection Quality is the most potentially distinctive Project OI idea and the most vulnerable to construct inflation.

The correct current status is:

> **provisional integrative hypothesis**

not:

> **validated constitutive dimension**

### 7.6 Causal Order

The model contains logical and temporal dependencies.

It should not imply that:

- every episode follows one sequence;
- every transition is necessary;
- or each stage causes the next independently.

### 7.7 Falsifiability

Chapter 10 now identifies evidence that would count against the construct.

The next empirical programme must make those tests operational and compare Project OI against simpler adjacent models.

---

## 8. Adversarial Scenario Tests

### 8.1 Founder-Led Five-Person Business

The founder notices, interprets, decides and repairs every important issue.

**Challenge:** Is this Organisational Intelligence or individual intelligence with organisational effect?

**Review position:** A bounded weak OI claim may be possible where the founder’s capability is organisationally enacted and retained. A strong OI claim requires evidence that orientation, authority, memory and response persist beyond the founder’s unaided cognition and continuous availability.

### 8.2 One-Off Crisis Team

A temporary group responds brilliantly to an emergency and then dissolves.

**Challenge:** Does exceptional collective performance demonstrate OI?

**Review position:** It demonstrates collective intelligence or an intelligent episode. It demonstrates OI only where a persistent organisational system retains or can reproduce the response capacity.

### 8.3 High-Performing Harmful Organisation

The organisation senses, coordinates and adapts effectively while exploiting workers or externalising harm.

**Challenge:** Does describing it as intelligent legitimise it?

**Review position:** The organisation may display instrumental OI. Responsible-exercise evidence fails. Consequential use of Project OI should never report capability without the governance finding.

### 8.4 Inter-Organisational Ecosystem

Several organisations coordinate through contracts and shared platforms but no actor owns the whole system.

**Challenge:** Where does authority, memory and feedback reside?

**Review position:** An ecosystem-level OI claim is valid only if the evaluator can identify a bounded governance, identity and feedback structure. Otherwise the claim should remain at the participating-unit or network-process level.

### 8.5 AI-Heavy Operation

A small business performs sophisticated work through one model provider but cannot verify, reproduce or continue the work if access changes.

**Challenge:** Has the organisation developed capability?

**Review position:** It has useful provider-enabled performance and possibly borrowed capability. A full internal capability claim is not supported.

### 8.6 Artefact-Rich Bureaucracy

The organisation has:

- dashboards;
- a knowledge graph;
- formal decision records;
- Workflows;
- lessons databases;
- and transformation programmes.

The same preventable failures recur.

**Challenge:** Does infrastructure demonstrate OI?

**Review position:** No. The artefacts are enablers or proxies. The failed transitions and absent learning persistence are negative evidence.

---

## 9. Measurement and Diagnostic Review

### 9.1 What Can Be Claimed Now

The BOK can support:

- bounded episode analysis;
- capability-specific inquiry;
- transition tracing;
- evidence-portfolio design;
- and hypothesis generation.

### 9.2 What Cannot Be Claimed Now

The BOK does not support:

- an OI score;
- a validated maturity model;
- normative benchmarking across firms;
- automated diagnosis;
- causal attribution from survey data alone;
- or employee ranking.

### 9.3 Core Evidence Requirement

A complete OI claim should contain evidence from:

```text
Orient
        +
Coordinate
        +
Improve
        +
Transition integrity
        +
Governance
        +
Outcome and risk
        +
Persistence
```

### 9.4 Diagnostic Layering

The release should expose:

1. the integrated cycle;
2. seven failure classes;
3. sixteen quality families;
4. eight evidence roles;
5. source-level details only when needed.

### 9.5 Metric Reactivity

Any later OI assessment may change:

- reporting;
- attention;
- incentives;
- and behaviour.

The instrument must be evaluated as an organisational intervention.

---

## 10. Governance, Ethics and Power Review

### 10.1 Responsible Exercise

The current responsible-exercise statement is strong enough to retain.

### 10.2 Purpose

Purpose must be:

- explicit;
- revisable;
- and contestable.

It cannot be assumed legitimate merely because it is organisationally authorised.

### 10.3 Power

Power affects the complete cycle:

```text
Signal
Context
Expertise
Decision
Execution
Evaluation
Memory
Capability
```

The BOK identifies this but has not studied it with the same depth as information processing, knowledge, coordination and capability.

### 10.4 Voice Is Not Decision Authority

Representation, participation, veto, appeal and decision rights should remain distinct.

### 10.5 Responsible-Use Reporting

For material use, a report should state separately:

- OI capability;
- responsible-exercise conditions;
- affected interests;
- rights and legal boundary;
- and unresolved harm.

---

## 11. Human–AI Review

### 11.1 What Survives

The BOK correctly treats AI as:

- participant;
- capability element;
- source of output;
- and potential actor within delegated authority.

It does not treat a model as the organisation’s intelligence.

### 11.2 What Remains Weak

The evidence base remains:

- model-specific;
- task-specific;
- provider-specific;
- time-sensitive;
- and concentrated in a small set of occupational settings.

### 11.3 Agent Authority

The identity, authority, state, tool, evidence and stop-control requirements are defensible as governance heuristics.

They are not yet an established organisation-theory construct.

### 11.4 Human Capability

AI can:

- augment;
- distribute;
- substitute;
- homogenise;
- and erode.

No one of those mechanisms should become the default assumption.

### 11.5 Provider Dependence

Borrowed Capability, Capability Opacity and Capability Sovereignty should remain:

- narrow;
- provisional;
- and explicitly connected to established adjacent literature.

---

## 12. Targeted 2026 Source Verification

This review checked a limited set of current primary sources.

### 12.1 Jagged Technological Frontier

**Verified:** The final Organization Science article was published online on 11 March 2026 and reports 758 participants. The BOK citation and principal sample statement are consistent with the final publication.

### 12.2 The Cybernetic Teammate

**Correction required:** The 2025 NBER working paper reports 776 professionals. The final Organization Science article published online on 12 June 2026 reports 791 professionals. OI-BOK-005 uses 776 while citing the final article.

### 12.3 Generative AI and High-Skilled Software Work

**Correction required:** The final Management Science article published online on 27 February 2026 is authored by Kevin Zheyuan Cui, Mert Demirer, Sonia Jaffe, Leon Musolff, Sida Peng and Tobias Salz. OI-BOK-009 contains a different author list.

### 12.4 NIST AI Agent Standards Initiative

**Verified:** NIST launched the initiative on 17 February 2026 and the initiative page records an update on 20 April 2026.

### 12.5 NIST AI Agent Security Response Analysis

**Verified:** NIST AI 800-5 was published on 18 May 2026. It is a synthesis of RFI responses, not an empirical prevalence study.

### 12.6 NCCoE Identity and Authorisation Concept Paper

**Verified with qualification:** The concept paper is a draft published on 5 February 2026. The BOK should preserve its draft and project-scoping status.

### 12.7 Anthropic Harness Design

**Verified with qualification:** The Anthropic Engineering article was published on 24 March 2026. It is detailed vendor engineering evidence, not independent causal research.

### 12.8 Verification Boundary

This targeted review does not certify the other bibliographic entries.

The complete source corpus still requires one controlled verification pass.

---

## 13. SMB Applicability Review

### 13.1 Strength

Every domain chapter includes a proportionate SMB interpretation.

### 13.2 Weakness

Those sections are:

- reasoned applications;
- not field evidence.

### 13.3 Primary Risks

SMB settings challenge the model through:

- founder dependency;
- informal authority;
- tacit context;
- low sample size;
- concentrated capability;
- limited evaluation capacity;
- and provider dependence.

### 13.4 Post-BOK Priority

The first empirical programme should trace a small set of complete SMB episodes rather than launch a broad survey.

---

## 14. Product Independence and Editorial Integrity

The roadmap explicitly required the product, architecture and blog workstreams to remain outside the BOK during completion.

The release chapters should therefore contain:

- no product-specific implication section;
- no product-specific object assumption;
- no article backlog;
- no automatic companion-output commitment;
- and no capitalised generic term inherited only from product terminology.

This is a release-integrity issue, not a stylistic preference.

---

## 15. Finding Register

| ID | Severity | Domain | Finding | Release gate | Disposition |
| --- | --- | --- | --- | --- | --- |
| OI-REV-001 | SURVIVES CHALLENGE | Construct boundary | One descriptive construct with a separate responsible-exercise condition is defensible | No | Retain |
| OI-REV-002 | SURVIVES CHALLENGE | Parsimony | Orient, Coordinate and Improve remain the strongest parsimonious higher-order structure | No | Retain with wording guardrail |
| OI-REV-003 | SURVIVES CHALLENGE | Circularity | The separation of capability, implementation, output, outcome and responsible exercise materially reduces circularity | No | Retain |
| OI-REV-004 | SURVIVES CHALLENGE | Measurement | Deferring a single composite OI score is correct | No | Retain |
| OI-REV-005 | SURVIVES CHALLENGE | Scope | No additional substantive chapters are required | No | Retain |
| OI-REV-006 | ACCEPTED TENSION | Mechanism | The feedback-coupled mechanism is coherent but remains a hypothesis | No | Preserve explicitly as unresolved |
| OI-REV-007 | BLOCKER | Intellectual lineage and novelty | The final chapter under-cites the explicit Organisational Intelligence lineage | Yes | Correct before release |
| OI-REV-008 | MAJOR | Novelty claim | The contribution should be described as an integrative construct and operational research programme, not a new general theory | Yes | Narrow claim |
| OI-REV-009 | MODERATE | Core definition | Relevant signals are not self-identifying | No | Clarify |
| OI-REV-010 | MAJOR | Core definition | Collective response is insufficiently bounded for founder-led and highly centralised organisations | Yes | Clarify construct boundary |
| OI-REV-011 | MAJOR | Core definition | Improve retains a teleological and value-laden ambiguity | Yes | Clarify normative boundary |
| OI-REV-012 | MAJOR | Persistence | Persistence is constitutive but not yet operationalised sufficiently | Yes | Add evidence criteria |
| OI-REV-013 | MAJOR | Unit of analysis | The focal organisational-system definition is too permissive without a claim-boundary protocol | Yes | Narrow unit rules |
| OI-REV-014 | MAJOR | Multilevel emergence | Evidence aggregation from individuals and teams to the organisation remains under-specified | Yes | Add multilevel guardrail |
| OI-REV-015 | ACCEPTED TENSION | Operational capability model | The six operational capabilities are useful but not demonstrated as mutually exclusive or necessary | No | Preserve explicitly |
| OI-REV-016 | MODERATE | Connective mechanisms | Contextualise is more recurrent than a one-way bridge from Sense to Know | No | Clarify representation |
| OI-REV-017 | MAJOR | Integrated states | Organisational Orientation remains central but less directly grounded than the chapter-owned capabilities | Yes | Strengthen construct boundary |
| OI-REV-018 | MAJOR | Connection Quality | Connection Quality is useful but currently overstates constitutive status | Yes | Narrow status |
| OI-REV-019 | MAJOR | Loop closure | Loop closure lacks a practical temporal threshold | Yes | Add evidence threshold |
| OI-REV-020 | ACCEPTED TENSION | Evidence architecture | The eight-role evidence portfolio is a synthesis, not an assessment instrument | No | Preserve limitation |
| OI-REV-021 | MAJOR | Quality architecture | The Sense quality profile is retrofitted in Chapter 10 because Chapter 1 lacks a source quality section | Yes | Correct source asymmetry |
| OI-REV-022 | MAJOR | Terminology | A 429-term glossary exceeds the parsimonious core required for release | Yes | Tier and simplify |
| OI-REV-023 | MODERATE | Terminology | The debt, integrity, laundering, opacity and sovereignty term families remain rhetorically strong and empirically weak | No | Retain as provisional |
| OI-REV-024 | MAJOR | Diagnostic architecture | The 437 failure modes, 197 quality dimensions and 253 indicators create diagnostic overload | Yes | Layer the diagnostic model |
| OI-REV-025 | MODERATE | Falsification | Falsification expectations are directionally useful but not yet operational | No | Clarify research status |
| OI-REV-026 | MAJOR | Power and representation | Power is recognised but less theoretically developed than the capability cycle | Yes | Strengthen limitation and research agenda |
| OI-REV-027 | ACCEPTED TENSION | Cultural and legal variation | No universal authority, voice, privacy or accountability model is supported | No | Preserve explicitly |
| OI-REV-028 | MODERATE | Normative communication | Instrumentally capable but irresponsibly governed is analytically useful but publicly easy to misread | No | Clarify communication |
| OI-REV-029 | MODERATE | Human–AI | AI receives disproportionate coverage relative to its evidential maturity | No | Rebalance presentation |
| OI-REV-030 | MAJOR | AI evidence maintenance | AI evidence expiry is identified but not yet implemented as a release-control process | Yes | Implement maintenance control |
| OI-REV-031 | MODERATE | AI implementation concepts | Agent execution envelope is an implementation heuristic rather than a core OI construct | No | Reclassify |
| OI-REV-032 | MAJOR | AI capability and dependence | Borrowed Capability, Capability Opacity and Capability Sovereignty need stronger adjacent-literature challenge | Yes | Narrow and challenge |
| OI-REV-033 | ACCEPTED TENSION | Human capability | AI-driven human capability erosion is plausible but longitudinally under-evidenced | No | Preserve limitation |
| OI-REV-034 | MODERATE | Source type | NIST guidance and Anthropic engineering evidence must remain visibly different from peer-reviewed research | No | Standardise evidence labels |
| OI-REV-035 | BLOCKER | Current-source accuracy | The Cybernetic Teammate sample size is inconsistent with the final published article | Yes | Correct factual detail |
| OI-REV-036 | BLOCKER | Current-source accuracy | The software-developer field-experiment citation has an incorrect author list | Yes | Correct citation |
| OI-REV-037 | MINOR | Source manifest | The Cybernetic Teammate source is misclassified as a conference, preprint or working paper | No | Correct metadata |
| OI-REV-038 | BLOCKER | Product independence | Chapters 1–3 retain obsolete product, companion-output and editorial-workstream content | Yes | Remove before release |
| OI-REV-039 | MAJOR | Terminology and product independence | Workflow, Agent and Run are capitalised across the BOK without general research definitions | Yes | Normalise terminology |
| OI-REV-040 | BLOCKER | Metadata and internal consistency | Chapter metadata still uses obsolete capability names and production states | Yes | Correct metadata |
| OI-REV-041 | MAJOR | Bibliographic integrity | The bibliography is not release-ready as one controlled scholarly apparatus | Yes | Complete source review |
| OI-REV-042 | MAJOR | SMB applicability | SMB relevance is plausible and well interpreted, but not empirically demonstrated | Yes | Preserve as unvalidated application hypothesis |
| OI-REV-043 | MODERATE | Usability and release architecture | The BOK requires a layered reader path rather than linear consumption of the full corpus | No | Add reader architecture |
| OI-REV-044 | MINOR | Source manifest methodology | The 283 unique-source count remains provisional | No | Retain caveat |

The complete CSV register contains:

- source scope;
- finding;
- adversarial concern;
- required action;
- release-gate status;
- and disposition.

---

## 16. Required Correction Plan

### 16.1 Correction Sequence

```text
P0 factual, scope and metadata corrections
        ↓
P1 construct, glossary and evidence clarifications
        ↓
Bibliographic and AI currency review
        ↓
Regenerate derived registers
        ↓
Final consistency proof
        ↓
OI-BOK-RELEASE-001
```

### 16.2 Correction Register

| ID | Priority | Target | Section | Action |
| --- | --- | --- | --- | --- |
| OI-COR-001 | P0 | Project-OI-BOK-010-Integrated-and-Responsible-Organisational-Intelligence-v0.1.md | §17 Relationship to Adjacent Constructs; §33 Selected References | Substantive source and lineage correction |
| OI-COR-002 | P0 | OI-BOK-001, OI-BOK-002 and OI-BOK-003 | Metadata; OI-BOK-002 §§28 and 30; OI-BOK-003 §§28 and 30 | Scope cleanup |
| OI-COR-003 | P0 | OI-BOK-001 through OI-BOK-010 | Top metadata blocks | Metadata reconciliation |
| OI-COR-004 | P0 | Project-OI-BOK-005-Coordination-and-Collective-Action-v0.1.md | §8.13 Human–AI Teaming; reference 14 | Factual correction |
| OI-COR-005 | P0 | Project-OI-BOK-009-Capability-Development-and-Adaptation-v0.1.md | Reference 25 and related source-manifest occurrence | Bibliographic correction |
| OI-COR-006 | P1 | Project-OI-BOK-010-Integrated-and-Responsible-Organisational-Intelligence-v0.1.md | §3 Final Working Definition | Construct clarification |
| OI-COR-007 | P1 | OI-BOK-010 and OI-BOK-GLO-001 | Chapter 10 §§7 and 19; glossary system terms | Unit-of-analysis clarification |
| OI-COR-008 | P1 | OI-BOK-010 | §6.2 Organisational Orientation | Construct-boundary strengthening |
| OI-COR-009 | P1 | OI-BOK-010 | §§3.2, 9 and OI-IP-009 | Working-construct narrowing |
| OI-COR-010 | P1 | OI-BOK-010 | §8.4 Feedback Closure; §19 Evidence Architecture | Evidence-threshold clarification |
| OI-COR-011 | P1 | OI-BOK-001 | New bounded quality section | Source asymmetry correction |
| OI-COR-012 | P1 | OI-BOK-GLO-001 | Glossary architecture and open terminology decisions | Glossary restructuring |
| OI-COR-013 | P1 | OI-BOK-DIAG-001 and release reader path | Diagnostic architecture | Layering |
| OI-COR-014 | P1 | OI-BOK-010 and OI-BOK-RELEASE-001 | Power, representation and limitations | Theoretical limitation strengthening |
| OI-COR-015 | P1 | OI-BOK source chapters and OI-BOK-GLO-001 | Generic terminology | Terminology normalisation |
| OI-COR-016 | P1 | All chapter reference sections and INDEX source files | Bibliography | Complete bibliographic verification |
| OI-COR-017 | P1 | INDEX source manifest and AI-era chapter claims | 18 time-sensitive source records | Currency review |
| OI-COR-018 | P1 | OI-BOK-009, OI-BOK-010 and GLO | Borrowed Capability, Capability Opacity and Capability Sovereignty | Working-term narrowing |
| OI-COR-019 | P2 | OI-BOK-INDEX-001 or OI-BOK-RELEASE-001 | Reader path | Usability architecture |
| OI-COR-020 | P2 | OI-BOK-RELEASE-001 | Claims and validation status | Release language |
| OI-COR-021 | P0 | All derived BOK registers | Regeneration after source corrections | Traceability regeneration |

### 16.3 Correction Boundary

The correction phase should be bounded.

It should not:

- add a chapter;
- rewrite every domain chapter;
- expand the literature indefinitely;
- create product architecture;
- build a maturity model;
- or reopen the blog programme.

---

## 17. Claims Permitted in the First Release

The release may say:

- Project OI provides a coherent literature-grounded working synthesis.
- It defines Organisational Intelligence at the organisation level.
- It proposes Orient, Coordinate and Improve.
- It operationalises the construct through Sense, Know, Choose, Mobilise, Learn and Adapt.
- It makes context, authority, outcome feedback, memory and capability change explicit.
- It proposes Connection Quality as a research hypothesis.
- It provides traceable propositions, failure modes, quality families and evidence roles.
- It treats AI as an organisational participant whose capability and authority require governance.
- It defines a falsifiable post-BOK empirical programme.

The release may not say:

- Project OI invented Organisational Intelligence.
- Project OI is the first human–machine OI theory.
- The six capabilities are empirically proven dimensions.
- Connection Quality is a validated construct.
- The evidence portfolio is a validated assessment.
- The BOK predicts organisational performance generally.
- The model has been validated for SMBs.
- The BOK provides an OI maturity score.
- The product implements the BOK.
- The current AI claims are timeless.

---

## 18. Final Verdict

> **Retain the BOK. Do not add chapters. Correct the release blockers, narrow the vulnerable claims, tier the terminology, reverify the source base and regenerate the derived registers.**

The model is now coherent enough to justify release work.

It is not yet coherent enough to justify release without correction.

The appropriate next activity is:

> **Project OI BOK Final Correction Pass**

That pass should execute OI-COR-001 through OI-COR-021 in dependency order.

After the corrections and regeneration are complete, create:

> **OI-BOK-RELEASE-001 — BOK Completion Record**

The product, architecture, implementation-pattern and blog workstreams remain paused until the Completion Record.

---

## 19. Review Guardrail

> **Adversarial review is not successful because it produces more criticism. It is successful when it leaves a smaller, clearer and more falsifiable construct, preserves unresolved evidence honestly, removes product and publication contamination, and defines a correction path that can finish rather than restart the research programme.**
