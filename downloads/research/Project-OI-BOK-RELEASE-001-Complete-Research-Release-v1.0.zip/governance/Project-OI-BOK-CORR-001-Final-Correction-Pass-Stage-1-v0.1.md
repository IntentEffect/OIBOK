# Project OI Body of Knowledge

# Final Correction Pass — Stage 1: Source Chapter Corrections

**Artefact ID:** OI-BOK-CORR-001  
**Version:** 0.1  
**Status:** Stage 1 complete; source chapters corrected to v0.2  
**Review authority:** OI-BOK-REVIEW-001  
**Date:** 15 August 2026  
**Release status:** Not released; bibliography, source lifecycle and derived-register regeneration remain  
**Product and architecture status:** Deferred  
**Blog status:** Paused

---

## 1. Purpose

This pass implements the source-controlled chapter corrections that should occur before the derived glossary, proposition, diagnostic, traceability, source-manifest and checksum artefacts are regenerated.

It creates corrected v0.2 copies of OI-BOK-001 through OI-BOK-010 and preserves the v0.1 files as historical working artefacts.

---

## 2. Corrections Completed

The source chapters now include:

- direct representation of the explicit Organisational Intelligence lineage in Chapter 10;
- narrower contribution and novelty language;
- removal of product-specific and obsolete blog-companion content from Chapters 1–3;
- metadata aligned to Sense, Know, Choose, Mobilise, Learn and Adapt;
- a source-owned Signals and Attention quality section;
- corrected 2026 AI source details for the Cybernetic Teammate and software-developer field experiments;
- clarification of relevant signals, collective response, Improve and persistence;
- a unit-of-analysis and multilevel-evidence protocol;
- a stronger Organisational Orientation boundary;
- persistence and loop-closure evidence thresholds;
- Connection Quality narrowed to an integrative research hypothesis;
- stronger power and representation limitations;
- explicit statement that OI applies without AI;
- narrowed status for Borrowed Capability, Capability Opacity and Capability Sovereignty;
- and normalisation of generic workflow, AI agent and run terminology.

---

## 3. Corrections Deliberately Deferred to Stage 2

Stage 2 must complete:

1. tiering and core indexing of the consolidated glossary;
2. layering of the diagnostic system;
3. complete bibliography verification and one house style;
4. current-status review of all 18 time-sensitive AI and Agent sources;
5. reader-path architecture in the updated index;
6. regeneration of PROP, DIAG, TRACE, OPEN and INDEX artefacts;
7. regeneration of JSON, CSV, checksum and bundle outputs;
8. and a final source-to-derived consistency proof.

The v0.2 chapters should not yet be described as a formal BOK release.

---

## 4. Correction Status

| Correction | Status | Result |
| --- | --- | --- |
| OI-COR-001 | Implemented | Chapter 10 now contains direct explicit OI lineage and bounded contribution wording. |
| OI-COR-002 | Implemented | Product and blog companion content removed from Chapters 1–3 release copies. |
| OI-COR-003 | Implemented | Chapter metadata aligned to final capabilities and bridge functions. |
| OI-COR-004 | Implemented | Cybernetic Teammate final sample corrected to 791; version distinction recorded. |
| OI-COR-005 | Implemented | Software-developer study author list and estimate wording corrected. |
| OI-COR-006 | Implemented | Definition interpretation notes added for relevance, collective response, Improve and persistence. |
| OI-COR-007 | Implemented | Unit-of-analysis and multilevel evidence protocol added. |
| OI-COR-008 | Implemented | Organisational Orientation boundary test added. |
| OI-COR-009 | Implemented | Connection Quality narrowed to an integrative research hypothesis. |
| OI-COR-010 | Implemented | Persistence and loop-closure evidence thresholds added. |
| OI-COR-011 | Implemented | Chapter 1 now owns a clearly labelled eight-dimension Sense quality synthesis. |
| OI-COR-012 | Pending Stage 2 | Glossary tiering and core index require derived-artefact revision. |
| OI-COR-013 | Pending Stage 2 | Diagnostic front-layer revision requires derived-artefact revision. |
| OI-COR-014 | Implemented | Power limitation and critical-literature research gap strengthened. |
| OI-COR-015 | Implemented | Generic Workflow, Agent and Run terminology normalised in chapter prose. |
| OI-COR-016 | Pending Stage 2 | Complete bibliographic verification and house-style normalisation remain. |
| OI-COR-017 | Pending Stage 2 | Full lifecycle verification of all 18 time-sensitive AI sources remains. |
| OI-COR-018 | Implemented | Borrowed Capability, Capability Opacity and Capability Sovereignty narrowed and linked to adjacent concepts. |
| OI-COR-019 | Pending Stage 2 | Reader-layer architecture belongs in updated index/release package. |
| OI-COR-020 | Pending release record | Final release limitations and permitted-claim language will be recorded after source verification. |
| OI-COR-021 | Pending Stage 2 | Derived registers and checksums will be regenerated after bibliography and source lifecycle review. |


---

## 5. Source Chapter Inventory

- `Project-OI-BOK-001-Signals-and-Attention-v0.2.md` — 3,771 words — SHA-256 `c25eda785605dd7f9a5375ef3889b7dedca10ea03390ed607e94f17077b99009`
- `Project-OI-BOK-002-Organisational-Context-v0.2.md` — 7,204 words — SHA-256 `4432f87f4ec7797dcf4b3a821a9b565bfdf43dee3a62dc767cb83165f9284f73`
- `Project-OI-BOK-003-Knowledge-and-Expertise-v0.2.md` — 8,442 words — SHA-256 `080199b6e054738bdd9038f034005e4487027f461cfcc7b695c8130b651a5b95`
- `Project-OI-BOK-004-Decision-and-Authority-v0.2.md` — 10,104 words — SHA-256 `20322351f888aacad98132772280219947b8d44b9796ca529192b4310cf8d18d`
- `Project-OI-BOK-005-Coordination-and-Collective-Action-v0.2.md` — 10,214 words — SHA-256 `6f951e2f6389d8a2b68312f306f5d730666117ea4b3df7bb0b365c9bfc41b587`
- `Project-OI-BOK-006-Execution-and-Operational-Reliability-v0.2.md` — 12,659 words — SHA-256 `1ff3e9a0ceb11e2639cdec339cca16e21cc1bbef23d4301febb9b2b9257c353f`
- `Project-OI-BOK-007-Outcomes-Feedback-and-Evaluation-v0.2.md` — 11,617 words — SHA-256 `0bfa3d8c0d1379d73dafd5004a7370570091272b608c73511265e573f66bf8fc`
- `Project-OI-BOK-008-Organisational-Memory-Reflection-and-Learning-v0.2.md` — 13,933 words — SHA-256 `5738e85968dbc469d25606d79b7cfdfee6685ead067f7ef9e13fb2839bca6124`
- `Project-OI-BOK-009-Capability-Development-and-Adaptation-v0.2.md` — 14,428 words — SHA-256 `a77fd539600c0e5a8cacc563004d38f7fde5a4a540f619daa4d087440a708b3a`
- `Project-OI-BOK-010-Integrated-and-Responsible-Organisational-Intelligence-v0.2.md` — 13,305 words — SHA-256 `794ea416c9f8b9d9b0a301c290101d9a18b69adf10375c065ada3562278bbccf`


---

## 6. Validation Checks

The Stage 1 validation checks confirm:

- ten v0.2 source chapters exist;
- no release chapter contains the product name;
- no release chapter retains obsolete companion-output metadata;
- the final Cybernetic Teammate sample is represented as 791 when the final publication is cited;
- the software-developer study uses the published author list;
- Chapter 1 contains the new Sense quality section;
- Chapter 10 contains the explicit OI lineage, unit protocol, orientation boundary, persistence threshold and loop-closure threshold;
- generic product-style capitals were removed from chapter prose while proper source titles remain in bibliographies;
- and all v0.1 source chapters remain unchanged as historical working artefacts.

---

## 7. Next Active Work

The next active artefact is:

> **OI-BOK-CORR-002 — Bibliographic, AI Evidence and Derived-Register Regeneration Pass**

After CORR-002, run a final consistency proof and create:

> **OI-BOK-RELEASE-001 — Body of Knowledge Completion Record**

---

## 8. Guardrail

> **Stage 1 corrects the source chapters without pretending that the derived corpus is already current. The BOK remains unreleased until the bibliography, time-sensitive evidence and every dependent register have been regenerated and verified.**
