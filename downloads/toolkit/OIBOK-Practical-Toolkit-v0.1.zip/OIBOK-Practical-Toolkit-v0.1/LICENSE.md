# OIBOK Practical Toolkit licence

Original guides, blank templates and fictional worked examples in this package are licensed under Creative Commons Attribution-ShareAlike 4.0 International, CC BY-SA 4.0.

Licence deed: https://creativecommons.org/licenses/by-sa/4.0/
Legal code: https://creativecommons.org/licenses/by-sa/4.0/legalcode.en

Founded by Intent & Effect, developed by the OIBOK community.

Contributors retain copyright in their original contributions. This notice does not transfer copyright.

When sharing the material or an adaptation, provide appropriate credit, link to the licence, identify changes and comply with the ShareAlike terms. Refer to the legal code for the complete conditions.

Suggested credit:
OIBOK Practical Toolkit, version 0.1, 22 November 2026. Founded by Intent & Effect, developed by the OIBOK community. CC BY-SA 4.0. Include a source link and describe changes when redistributing.

The publication licence applies to original toolkit content. It does not grant trademark rights or relicense linked third-party source material. The Creative Commons badge is official Creative Commons artwork, reproduced from its original asset without alteration.

Using a template does not require publication of your completed records. The rights and confidentiality of organisational records must be considered separately. Sharing adapted template content remains subject to the applicable licence terms.

