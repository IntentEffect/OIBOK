# OIBOK Practical Toolkit

Version 0.1 | 22 November 2026

Founded by Intent & Effect, developed by the OIBOK community.

## What this pack contains

Use the toolkit to examine one recurring organisational decision or workflow, design an improvement and evaluate its effects.

- 00 OIBOK Practical Toolkit Guide: how to use the resources, evidence conventions, ten-chapter map, reuse and sources.
- 01 Organisational Intelligence Practice Review: facilitator guide, four blank worksheet pages and two completed example pages. Includes the Context and Knowledge Map and Decision and Coordination Canvas.
- 02 AI Opportunity and Work Design Canvas: facilitator guide, three blank worksheet pages and two completed example pages.
- 03 Outcome and Learning Record: facilitator guide, four blank worksheet pages and two completed example pages.
- Markdown versions of all four documents for editing or later website publication.
- The official CC BY-SA badge in SVG format.

The Word files contain ordinary editable text and tables. Copy the blank worksheet sections into a working file, replace the bracketed prompts, and extend fields or add rows as needed. Keep the completed examples separate from your organisation's own evidence.

## Suggested first use

1. Choose one recurring workflow or decision with an accountable owner.
2. Bring several contrasting cases, source records and available outcome data.
3. Run a 90 minute Practice Review and select one improvement to investigate.
4. If AI is being considered, use the AI canvas in a 75 to 90 minute session to compare options and define the work, authority, context and pilot conditions.
5. Complete the Outcome and Learning Record's plan before changing the work. Allow about 30 minutes.
6. Collect the agreed evidence over a suitable observation window. Review results in a 45 minute session, record a decision and assign learning actions.
7. Schedule a later 15 minute check to see whether changes to knowledge and working practice persist.

These timings are starting suggestions and can be adapted. If the chosen change contains no AI, connect the Practice Review directly to the Outcome and Learning Record.

## Version and example status

This is a new set of OIBOK practice resources for piloting. It is not an amendment to a canonical OIBOK research release, a validated intelligence or maturity measure, or a certification scheme.

Harbour Services is fictional. All example records, counts, targets and results are invented for instruction. They are not observations of an actual organisation or evidence that OIBOK has been validated. The pilot compares a combined intervention with existing work; it does not isolate an AI-only effect. The later persistence check remains pending.

The resources were drafted with AI assistance. Sources and internal consistency were checked during preparation. Independent editorial review and field evaluation remain future steps.

## Contribution feedback

Capture the following when testing a tool:

- Tool name and version
- Workflow or decision examined
- Participants and approximate effort
- Prompts that were useful, confusing or missing
- Adaptations made and why
- Decisions or actions the tool supported
- Observed consequences and competing explanations
- What would need checking before a stronger claim
- Permission and de-identification status of any material proposed for publication

Contributors retain copyright in their original work. Use the established OIBOK contribution channel when available and provide only material you have rights and permission to share.

## Reuse

Original guides, blank templates and worked examples are published under CC BY-SA 4.0. See LICENSE.md and the Toolkit Guide for attribution and scope.

Using the toolkit does not require you to publish completed organisational records. Keep those records in an appropriately controlled location. When redistributing adapted template content, comply with the licence terms.

Source references appear in the Toolkit Guide. Linked third-party material retains its own terms. The publication licence does not grant trademark rights.

## Package structure

The Word and Markdown versions use the same content. The Markdown files are a publishing starting point; they do not deploy or update a website.

